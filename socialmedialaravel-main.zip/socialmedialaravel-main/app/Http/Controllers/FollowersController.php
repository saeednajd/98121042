<?php

namespace App\Http\Controllers;

use App\Models\followers;
use App\Http\Requests\StorefollowersRequest;
use App\Http\Requests\UpdatefollowersRequest;

class FollowersController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorefollowersRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(followers $followers)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(followers $followers)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatefollowersRequest $request, followers $followers)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(followers $followers)
    {
        //
    }
}
